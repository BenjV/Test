autosubversion='1.2.23'
configversion=6
dbversion=11
rlsgrpdate='29-03-2018'
A7mapdate='29-03-2018'